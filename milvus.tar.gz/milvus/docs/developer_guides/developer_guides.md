# Milvus Developer Guides

​ by Rentong Guo Sep 15, 2020

## Acknowledgement

TODO: a formal acknowledgement.

main content: Rentong Guo, Qingxiang Chen (appendix b)

figures: Xuan Yang, Zhenshan Cao

design suggestions: Zhenshan Cao, Xi Ge, Yefu Chen, Guilin Gou, Yihao Dai, Jiquan Long, Xiaomeng Yi, Peng Xu, Hai Jin, Xiangzhou Guo
