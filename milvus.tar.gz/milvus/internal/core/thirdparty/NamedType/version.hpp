#pragma once

namespace fluent
{
#define NAMED_TYPE_VERSION_MAJOR 1
#define NAMED_TYPE_VERSION_MINOR 1
#define NAMED_TYPE_VERSION_PATCH 0
#define NAMED_TYPE_VERSION "1.1.0"
} // namespace fluent
